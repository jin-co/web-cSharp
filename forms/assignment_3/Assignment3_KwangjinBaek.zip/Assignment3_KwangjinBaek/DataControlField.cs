﻿namespace Assignment3_KwangjinBaek
{
    internal class DataControlField
    {
    }
}