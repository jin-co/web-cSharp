﻿namespace Bookstore.Components
{
    public class SharedPath
    {
        public const string Select = "~/Views/Shared/Components/Common/DropDown.cshtml";
    }
}
