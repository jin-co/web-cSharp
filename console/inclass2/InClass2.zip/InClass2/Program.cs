﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InClass2
{
    class Program
    {
        
        static void Main(string[] args)
        {
            // Joshua Cheeseman, Stephanie Noecker, Kwangjin Baek, Dalvir Singh
            // If the user inputs anything other than a number, the program gives an error message citing an incorrect format.
            // The answer is always calculating correctly.
            // The expected errors occur if you enter a non numerical input, as it cannot be used in any arithmetic
            // In terms of bettering efficiency, we could cut down on the parsing done from lines 29-33 to make it look a little better.
           
            int firstFour, lastTwo, numberIFive,resultMult,resultSub;
            double numberOnee, numberTwoo, numberThreee, numberFourr, numberFivee, firstDFour, lastDTwo;
            string numberOne, numberTwo, numberThree, numberFour, numberFive;
            Console.WriteLine("Please enter five two digit numbers");
            numberOne = Console.ReadLine();
            numberTwo = Console.ReadLine();
            numberThree = Console.ReadLine();
            numberFour = Console.ReadLine();
            numberFive = Console.ReadLine();
            numberOnee = double.Parse(numberOne);
            numberTwoo = double.Parse(numberTwo);
            numberThreee = double.Parse(numberThree);
            numberFourr = double.Parse(numberFour);
            numberFivee = double.Parse(numberFive);
            firstDFour = numberOnee + numberTwoo + numberThreee + numberFourr;
            lastDTwo = numberFourr + numberFivee;
            firstFour = (int)firstDFour;
            lastTwo = (int)lastDTwo;
            resultMult = firstFour * lastTwo;
            Console.WriteLine("The multiplication value is: " + resultMult);
            numberIFive = (int)numberFivee;
            resultSub = firstFour - numberIFive;
            Console.WriteLine("The subtraction value is: " + resultSub);
            
            
















        }

    }
}
