﻿using System;

namespace InClass3
{
    class Program
    {
        //Group Charlie Arvanitis, Kwangjin Baek, Junseo Yang, Megan Tran 
        //mtran7833@conestogac.on.ca
        //Kbaek7943 @conestogac.on.ca
        //jyang2918 @conestogac.on.ca
        //carvanitis7527@conestogac.on.ca

        static void Main(string[] args)
        {
            

            Console.Write("Enter First Number: ");
            double firstMethodNumb = double.Parse(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            double secondMethodNumb = double.Parse(Console.ReadLine());
            Console.Write("Enter Third Number: ");
            double thirdMethodNumb = double.Parse(Console.ReadLine());
            Console.Write("Enter Fourth Number: ");
            double fourthMethodNumb = double.Parse(Console.ReadLine());
            Console.WriteLine(MainMethod(firstMethodNumb, secondMethodNumb, thirdMethodNumb, fourthMethodNumb));

            Console.Write("Enter a word: ");
            string firstWord = Console.ReadLine();
            Console.Write("Enter a second word: ");
            string secondWord = Console.ReadLine();
            Console.Write(MainMethod(firstWord, secondWord));

        }

        static double MainMethod(double firstNumber, double secondNumber, double thirdNumber, double forthNumber)
        {
            return (firstNumber + secondNumber + thirdNumber + forthNumber) * 7;
        }
        
        static double MainMethod(double firstNumber, double secondNumber)
        {
            return (firstNumber / secondNumber);
        }

        static double MainMethod(double firstNumber, double secondNumber, double thirdNumber)
        {
            return (firstNumber * secondNumber * thirdNumber) / 2;
        }
        
        static string MainMethod(string firstWord, string secondWord)
        {
            return (firstWord + " " + secondWord);
        }

    }
}
