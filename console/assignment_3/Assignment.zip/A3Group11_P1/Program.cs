﻿using System;
using System.Threading;
using System.Xml.XPath;

namespace A3Group11_P1
{
    class Program
    {
        // Junseo Yang <Jyang2918@conestogac.on.ca>, Steven Clayton <Sclayton7258@conestogac.on.ca>, Kwangjin <Kbaek7943@conestogac.on.ca> 
        // The application lets users to choose an option from 1 ~ 3 to do calculations
        static void Main(string[] args)
        {
            bool sentinel = true;
            do
            {
                try
                {
                    Console.WriteLine("---------- Choose Number ----------\n1) Option\n2) Option\n3) Option");
                    Console.Write("\nPlease Choose an option: ");
                    int optionChoice = int.Parse(Console.ReadLine());

                    if (optionChoice == 1)
                    {
                        CountFromInput();
                    }

                    else if (optionChoice == 2)
                    {
                        DivideInputNum();
                    }

                    else if (optionChoice == 3)
                    {
                        sentinel = false;
                    }

                    else
                    {
                        Console.WriteLine("Sorry we only have options 1 ~ 3");
                    }
                }

                catch (FormatException fEx)
                {
                    Console.WriteLine("You have to enter a number" + fEx);
                }

                catch (DivideByZeroException zEx)
                {
                    Console.WriteLine("You can't divide by 0" + zEx);
                }

                catch (OverflowException oEx)
                {
                    Console.WriteLine("Invalid input" + oEx);
                }

                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }

            } while (sentinel);
            }

        // Option 1: it returns back 20 incremented numbers starting form the input number.
        static void CountFromInput()
        {
            Console.Write("\nPlease enter a number: ");
            int startingNum = int.Parse(Console.ReadLine());
            int[] subResult = new int[20];
            int[] total = new int[20];

            for (int i = 0, j = startingNum; i < 20; i++, j++)
            {
                subResult[i] = j;

                if (j % 2 == 0)
                {
                    total[i] = j * 7;
                }

                else
                {
                    total[i] = j * 8;
                }
            }
            Console.WriteLine("");

            foreach (int i in subResult)
            {
                Console.Write(i + " ");
            }

            Console.WriteLine("\n");

            foreach (int i in total)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine("\n");
        }

        // Option2: It gets the input number divided by 3 and displays.
        static void DivideInputNum()
        {
            bool goOn = true;

            while (goOn)
            {
                Console.Write("\n---Enter 'END' to quit---\n\tEnter a number: ");
                string input = Console.ReadLine();

                if (input == "end" || input == "END")
                {
                    goOn = false;
                }

                else
                {
                    double result = Convert.ToDouble(input) / 3;
                    Console.WriteLine("\nThe result {0:00} divided by 3\n= {1:#.##}", input, result);
                }
            }
        }
    }
}

