﻿/* 
 * Title : A3Group11P2
 * Student : Junseo Yang <Jyang2918@conestogac.on.ca>
 *           Steven Clayton <Sclayton7258@conestogac.on.ca>
 *           Kwangjin Baek<Kbaek7943@conestogac.on.ca>
 * Program : Computer Programmer/Analyst OC 00571-2001
 * Course Code : PROG1781 - Programming Concepts I Sec3
 * Professor : Orville Bailey
 * Assignment Due Date : Nov 13, 2020 11:59 PM
 * 
 * Goal : Write a C# (console) program to create an 
 *        interface that acts as a simple four number calculator.
 *        Your program should continue doing calculations until
 *        it is closed or exited. 
 * 
 * Note : Instead of a GUI keypad, this calculator will use console
 *        input to accept the four numbers to be used in the calculation.
 *        This calculator needs to prompt the user for ONE selection of
 *        any of these simple math operators: plus, minus, multiply, or divide. 
 * 
 * Instruction : 
 *                  Five (5) inputs will need to be prompted: 
 *                      1. one for the selected mathematical operation, 
 *                      2. one for the first input, 
 *                      3. one for the second input,
 *                      4. and one for the third input. 
 *                      5. and one for the fourth input. 
 *                      
 *                  The output will be displayed when the mathematical operation
 *                  is known and the four inputs (numbers) are entered.   
 *                      1. If the user selects addition (plus) add all numbers together.
 *                    	2. If the user selects subtraction only subtract(minus)  the third
 *                    	   number from the first number.
 *                    	3. If the user selects division (divide) divide the fourth number
 *                    	   by the sum of the first number and the second number (e.g. 4/(1+2)). 
 *                    	4. If the user selects multiplication (multiply), multiply only the
 *                    	   first and third numbers.
 *
 *                  The output will not be editable by the user. After the calculation is
 *                  executed, the application will display error messages (or other status
 *                  message), and can be as you deem appropriate. [4 marks]
 *                      1. The program only needs to run once then exit
 *                      2. This calculator will handle all errors using try/catch
 *                         statements. The error message output should display at least
 *                         3 different types of error (or status) messages, depending on what
 *                         the user has done incorrectly. Your program should be able to catch
 *                         all possible errors the user may do; it should not crash. [6 marks]
 * 
 */

using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A3Group11P2
{
    class Program
    {
        static void Main(string[] args)
        {
            string endThis = "N";
            while(endThis != "Y")
            {
                try
                {
                    // Request inputs from a user
                    Console.Write("Enter math operator either +, -, *, / : ");
                    string mathOperator = Console.ReadLine();

                    if (!(mathOperator == "+" || mathOperator == "-" || mathOperator == "*" || mathOperator == "/"))
                    {
                        throw new ArgumentOutOfRangeException("You should eneter a math operator either +, -, *, /.");
                    }

                    Console.Write("Enter the first input in a number : ");
                    double input1 = double.Parse(Console.ReadLine());
                    Console.Write("Enter the second input in a number : ");
                    double input2 = double.Parse(Console.ReadLine());
                    Console.Write("Enter the third input in a number : ");
                    double input3 = double.Parse(Console.ReadLine());
                    Console.Write("Enter the fourth input in a number : ");
                    double input4 = double.Parse(Console.ReadLine());

                    if (mathOperator == "/" && (input1 + input2) == 0 )
                    {
                        throw new DivideByZeroException("You cannot divde by zero.");
                    }

                    // Decision by math operator
                    switch (mathOperator)
                    {
                        case "+":
                            Console.WriteLine("\nResult : " + Add(input1, input2, input3, input4));
                            Console.WriteLine("Proof : \n\tResult = input1 + input2 + input3 + input4");
                            Console.WriteLine("\t" + Add(input1, input2, input3, input4) + " = " + input1 + " + " + input2 + " + " + input3 + " + " + input4);
                            break;
                        case "-":
                            Console.WriteLine("\nResult : " + Subtract(input1, input2, input3, input4));
                            Console.WriteLine("Proof : \n\tResult = input1 - input3");
                            Console.WriteLine("\t" + Subtract(input1, input2, input3, input4) + " = " + input1 + " - " + input3);
                            break;
                        case "/":
                            Console.WriteLine("\nResult : " + Divide(input1, input2, input3, input4));
                            Console.WriteLine("Proof : \n\tResult = input4 / (input1 + input2)");
                            Console.WriteLine("\t" + Divide(input1, input2, input3, input4) + " = " + input4 + " / (" + input1 + " + " + input2 + ")");
                            break;
                        case "*":
                            Console.WriteLine("\nResult : " + Multiply(input1, input2, input3, input4));
                            Console.WriteLine("Proof : \n\tResult = input1 * input3");
                            Console.WriteLine("\t" + Multiply(input1, input2, input3, input4) + " = " + input1 + " * " + input3);
                            break;
                        default:
                            Console.WriteLine("You entered wrong math operator.");
                            break;
                    }

                    Console.Write("\nDo you want to end the program? (Y/N) : ");
                    endThis = Console.ReadLine();

                    if (!(endThis == "Y" || endThis == "N"))
                    {
                        throw new ArgumentOutOfRangeException("You should eneter either Y or N");
                    }
                }

                // catch errors
                catch (ArgumentOutOfRangeException aEx)
                {
                    Console.WriteLine("This is a input error.\n" + aEx);
                }
                catch (DivideByZeroException zEx)
                {
                    Console.WriteLine("This is a divide by zero error.\n" + zEx);
                }
                catch (OverflowException oEx)
                {
                    Console.WriteLine("This is a overflow error.\n" + oEx);
                }
                catch (FormatException fEx)
                {
                    Console.WriteLine("This is a formatting error.\n" + fEx);
                }
                catch(Exception e)
                {
                    Console.WriteLine("This is a general error.\n" + e);
                }
                finally
                {
                    Console.WriteLine("This is the end of the program.\n\n");
                }
            } // End of while loop
        }

        static double Add(double input1, double input2, double input3, double input4)
        {
            return input1 + input2 + input3 + input4;
        }

        static double Subtract(double input1, double input2, double input3, double input4)
        {
            return input1 - input3;
        }

        static double Divide(double input1, double input2, double input3, double input4)
        {
            return input4 / (input1 + input2);
        }

        static double Multiply(double input1, double input2, double input3, double input4)
        {
            return input1 * input3;
        }
    }

}
