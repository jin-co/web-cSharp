﻿/* 
 * Title : A3Group11P1
 * Student : Junseo Yang <Jyang2918@conestogac.on.ca>
 *           Steven Clayton <Sclayton7258@conestogac.on.ca>
 *           Kwangjin Baek <Kbaek7943@conestogac.on.ca>
 * Program : Computer Programmer/Analyst OC 00571-2001
 * Course Code : PROG1781 - Programming Concepts I Sec3
 * Professor : Orville Bailey
 * Assignment Due Date : Nov 13, 2020 11:59 PM
 * 
 * Goal : You are creating a console-based program that allows
 *        the user to view a list of numbers and do a few calculations. 
 * 
 * Note : This program will be shown as a menu with three (3) options.
 *        The menu should be created with a do loop.
 *        You may user numbers or letter to represent each option.
 *        Any invalid option entered by the user should prompt the
 *        menu to reappear and ask the same three options.
 *        Any string entry by the user, in place of the expected numeric value should not crash the program.
 *        You must use the appropriate loop for each segment as stated for each question
 *  
 * Instruction : 
 *               Option 1
 *                  The first option is to display a list of 20 numbers
 *                  starting at a number the user specifies ; when the option
 *                  is selected – first ask the user for the starting number.
 *                  After the user provides this input, all the values should
 *                  be displayed at once as follows:
 *                    - User a for loop to increment through the numbers (beginning
 *                      with the starting number)
 *                    - For each number:  multiply the even ones by 7 and multiply
 *                      the odd numbers by 8.
 *
 *               Option 2
 *                  This option should be created using a while loop. It must display
 *                  the result of any number the user provides divided by 3. The option
 *                  should begin by asking the user for a number. – the program should
 *                  then display the result of that number divided by 3.
 *                  This process should be repeated until the user types “END” to return
 *                  to the original menu.
 *                   - Further explanation
 *                      If the user enters a number, then the result of the number the user
 *                      enters divided by 3 must be printed to the screen. The user will then
 *                      be asked for input again. This continues until the user wishes to end
 *                      the sequence by entering “END”. 
 *
 *               Option 3
 *                  The third option is to exit the program. 
 * 
 * 
 *               Your program must:
 *                  a.	Encapsulate the logic of options 1 and 2 each within their own method. [2 marks]
 *                  b.	The functionality of the menu is correct as described. [2 marks]
 *                  c.	Proper error handling. [3 marks]
 *                  d.	Adhere to coding standards as described by the course. Marks will be taken
 *                      off wherever coding standards are not followed.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A3Group11P1
{
    class Program
    {
        // Junseo Yang <Jyang2918@conestogac.on.ca>, Steven Clayton <Sclayton7258@conestogac.on.ca>, Kwangjin <Kbaek7943@conestogac.on.ca> 
        // The application lets users to choose an option from 1 ~ 3 to do calculations
        static void Main(string[] args)
        {
            bool sentinel = true;
            do
            {
                try
                {
                    Console.WriteLine("---------- Choose Number ----------\n1) Option\n2) Option\n3) Option");
                    Console.Write("\nPlease Choose an option (either 1, 2, 3) : ");
                    int optionChoice = int.Parse(Console.ReadLine());

                    if (optionChoice == 1)
                    {
                        CountFromInput();
                    }

                    else if (optionChoice == 2)
                    {
                        DivideInputNum();
                    }

                    else if (optionChoice == 3)
                    {
                        sentinel = false;
                    }

                    else
                    {
                        Console.WriteLine("Sorry we only have options 1 ~ 3");
                    }
                }

                catch (FormatException fEx)
                {
                    Console.WriteLine("You have to enter a number" + fEx);
                }

                catch (DivideByZeroException zEx)
                {
                    Console.WriteLine("You can't divide by 0" + zEx);
                }

                catch (OverflowException oEx)
                {
                    Console.WriteLine("Invalid input" + oEx);
                }

                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }

            } while (sentinel);
        }

        // Option 1: it returns back 20 incremented numbers starting form the input number.
        static void CountFromInput()
        {
            Console.Write("\nPlease enter a number: ");
            int startingNum = int.Parse(Console.ReadLine());
            int[] subResult = new int[20];
            int[] total = new int[20];

            for (int i = 0, j = startingNum; i < 20; i++, j++)
            {
                subResult[i] = j;

                if (j % 2 == 0)
                {
                    total[i] = j * 7;
                }

                else
                {
                    total[i] = j * 8;
                }
            }
            Console.WriteLine("");

            foreach (int i in subResult)
            {
                Console.Write(i + " ");
            }

            Console.WriteLine("\n");

            foreach (int i in total)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine("\n");
        }

        // Option2: It gets the input number divided by 3 and displays.
        static void DivideInputNum()
        {
            bool goOn = true;

            while (goOn)
            {
                Console.Write("\n---Enter 'END' to quit---\n\tEnter a number: ");
                string input = Console.ReadLine();

                if (input == "end" || input == "END")
                {
                    goOn = false;
                }

                else
                {
                    double result = Convert.ToDouble(input) / 3;
                    Console.WriteLine("\nThe result {0:00} divided by 3\n= {1:0.##}", input, result);
                }
            }
        }
    }
}
