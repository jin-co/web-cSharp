﻿using System;

namespace Assignment1_part2
{
    class TemperatureChanger
    {
        static void Main(string[] args)
        {
            double fahrenheit, celsius;
            string celsiusString;
            Console.WriteLine("Kwangjin Baek - Assignment 1 part 2\nName: Kwangjin Baek\nEmail: Kbaek7943@conestogac.on.ca");
            Console.Write("(temperature unit changer) Input temperature in celsious please: ");
            celsiusString = Console.ReadLine();
            // converting string to numeric data
            celsius = double.Parse(celsiusString);
            // converting celsius to fahrenheit using fomula
            fahrenheit = (celsius * 1.8) + 32;
            Console.WriteLine("The Celsius temp of " + celsius + " degrees converts to in " + fahrenheit
                + " Fahrenheit.");
            Console.WriteLine("Experience: No previous programming experience.\nCountry: Korea(Not North)");
        }
    }
}